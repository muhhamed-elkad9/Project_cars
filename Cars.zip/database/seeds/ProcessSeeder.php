<?php

namespace Database\Seeders;

use App\Models\process;
use Illuminate\Database\Seeder;

class ProcessSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // process::factory()->count(10)->create();
    }
}

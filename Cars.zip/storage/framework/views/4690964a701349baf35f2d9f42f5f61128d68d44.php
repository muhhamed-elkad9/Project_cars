<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
    شاشة السيارات
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    شاشة السيارات
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <a href="<?php echo e(route('car.create')); ?>" class="btn btn-success btn-sm" role="button" aria-pressed="true">اضافة
                    سيارة جديدة</a><br><br>
            </div>

            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="accordion gray plus-icon round">

                        <div class="row">
                            <div class="col-xl-12 mb-30">
                                <div class="card card-statistics h-100">
                                    <div class="card-body">
                                        <div class="d-block d-md-flex justify-content-between">
                                            <div class="d-block">
                                            </div>
                                        </div>
                                        <div class="table-responsive mt-15">
                                            <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                                data-page-length="50" style="text-align: center">
                                                <thead>
                                                    <tr class="text-dark">
                                                        <th>#</th>
                                                        <th>اسم السيارة</th>
                                                        <th>الشركة المصنعة</th>
                                                        <th>تاريخ الشراء</th>
                                                        <th>رقم اللوحة</th>
                                                        <th>الرقم التسلسلي</th>
                                                        <th>سنة الاصدار</th>
                                                        <th>عمر السيارة</th>
                                                        <th>المسافة المقطوعة</th>
                                                        <th>قيمة شراء السيارة</th>
                                                        <th>القيمة الحالية (حساب تلقائي للاهلاك)</th>
                                                        <th>العمليات</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e($car->car_name); ?></td>
                                                            <td><?php echo e($car->company_name_made); ?></td>
                                                            <td><?php echo e($car->car_year_buy); ?></td>
                                                            <td><?php echo e($car->car_number); ?></td>
                                                            <td><?php echo e($car->car_number_serial); ?></td>
                                                            <td><?php echo e($car->car_year_made); ?></td>
                                                            <td><?php echo e($car->car_age); ?></td>
                                                            <td><?php echo e($car->traveled_distance); ?></td>
                                                            <td><?php echo e($car->car_value_buy); ?></td>
                                                            <td><?php echo e($car->current_value); ?></td>
                                                            <td>
                                                                <a class="btn btn-info btn-sm"
                                                                    href="<?php echo e(route('car.edit', $car->id)); ?>"
                                                                    title="تعديل"><i class="fa fa-edit"></i></a>

                                                                <button type="button" class="btn btn-danger btn-sm"
                                                                    data-toggle="modal"
                                                                    data-target="#delete<?php echo e($car->id); ?>"
                                                                    title="حذف"><i class="fa fa-trash"></i></button>
                                                            </td>
                                                        </tr>


                                                        <!-- delete_modal_Grade -->
                                                        <div class="modal fade" id="delete<?php echo e($car->id); ?>"
                                                            tabindex="-1" role="dialog"
                                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 style="font-family: 'Cairo', sans-serif;"
                                                                            class="modal-title" id="exampleModalLabel">
                                                                            حذف السيارة
                                                                        </h5>
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <form
                                                                            action="<?php echo e(route('car.destroy', $car->id)); ?>"
                                                                            method="get">
                                                                            <?php echo csrf_field(); ?>
                                                                            هل انتا متاكد من حذف هذه السيارة
                                                                            <input id="id" type="hidden"
                                                                                name="id" class="form-control"
                                                                                value="<?php echo e($car->id); ?>">
                                                                            <div class="modal-footer">
                                                                                <button type="button"
                                                                                    class="btn btn-secondary"
                                                                                    data-dismiss="modal">اغلاق</button>
                                                                                <button type="submit"
                                                                                    class="btn btn-danger">حذف</button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
@toastr_js
@toastr_render
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\BackEnd\My Project\Cars\resources\views/car/index.blade.php ENDPATH**/ ?>